package classes;
//Enum contendo todas as poss�veis cores do jogo
 
public enum Color {
    RED,
    BLUE,
    NONE,
}